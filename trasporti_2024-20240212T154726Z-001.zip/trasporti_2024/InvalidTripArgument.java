package it.uniud.poo.trasporti_2024;

public class InvalidTripArgument extends Exception {
    public InvalidTripArgument(String msg) {
    }
}
