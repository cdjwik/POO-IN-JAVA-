package it.uniud.poo.trasporti_2024;

public class Client {
    public Client(String id, String name, String address) {
        // TODO
    }
}
