package it.uniud.poo.trasporti_2024;

public enum GoodsKind {
    LIQUID, SOLID, GAS, BOXES, CONTAINERS
}
