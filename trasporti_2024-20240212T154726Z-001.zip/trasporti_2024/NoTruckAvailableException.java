package it.uniud.poo.trasporti_2024;

public class NoTruckAvailableException extends Throwable {
    public NoTruckAvailableException(String msg) {
    }
}
